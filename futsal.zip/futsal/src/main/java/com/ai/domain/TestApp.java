package com.ai.domain;

import lombok.Data;

@Data
public class TestApp {
    private String title;
    private String text;
}