package com.ai.domain;

import lombok.Data;

import java.util.ArrayList;

@Data
public class LocationFieldDTO {
    private FieldDTO field;
    private double distance;
}
