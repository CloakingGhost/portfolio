package com.ai.domain;

import lombok.Data;

@Data
public class NoticeVO {
    private String tName, notice, regDate;
}
