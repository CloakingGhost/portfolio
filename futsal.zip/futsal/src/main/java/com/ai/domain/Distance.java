package com.ai.domain;

import lombok.Data;

@Data
public class Distance {
    private String field;
    private double distance;
}
