package com.ai.domain;

import lombok.Data;

@Data
public class RecordVO {
    private String field, Date, Time, vsTeam, result;
}
