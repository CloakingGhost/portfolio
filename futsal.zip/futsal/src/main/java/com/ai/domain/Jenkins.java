package com.ai.domain;

public class Jenkins {
    public static void main(String[] args) {

    }
}
