package com.ai.domain;

import lombok.Data;

@Data
public class ReservationVO {
	String date, regDate, time, field, price, state, type, refund, manner, mannerornot, fieldPic;
}