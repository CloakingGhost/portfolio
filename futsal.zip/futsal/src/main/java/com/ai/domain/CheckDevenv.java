package com.ai.domain;

public class CheckDevenv {
    // true 면 local
    // false 면 ec2
    public static final boolean DEVENV = true;
}
